<?php
// Ganti URL_API dengan URL API yang sesuai
$url = 'http://localhost:8000/kritik';

// Ambil parameter dari DataTables
$start = $_GET['start'] ?? 0;
$length = $_GET['length'] ?? 10;
$draw = $_GET['draw'] ?? 1;
$searchValue = $_GET['search']['value'] ?? ''; // Ambil nilai pencarian

// Menyesuaikan URL dengan parameter, termasuk pencarian
$url .= "?start=$start&length=$length&search=$searchValue";

// Menggunakan cURL untuk mengambil data dari API dengan URL yang telah disesuaikan
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// Eksekusi cURL dan ambil respons
$response = curl_exec($ch);
curl_close($ch);

// Decode data JSON
$data = json_decode($response, true);

// Menerapkan filter berdasarkan pencarian (nama)
if ($searchValue !== '') {
    $data = array_filter($data, function ($row) use ($searchValue) {
        $namaMatch = strpos(strtolower($row['nama']), strtolower($searchValue)) !== false;
        $departemenMatch = strpos(strtolower($row['departement']), strtolower($searchValue)) !== false;
        return $namaMatch || $departemenMatch;
    });
}

// Format data untuk DataTables
$output = [
    'draw' => $draw,
    'recordsTotal' => count($data), // Jumlah total data (tanpa filter)
    'recordsFiltered' => count($data), // Jumlah data setelah difilter
    'data' => array_slice($data, $start, $length), // Potong data sesuai dengan start dan length
];

// Mengembalikan data dalam format JSON
echo json_encode($output);
// var_dump($output);
?>
